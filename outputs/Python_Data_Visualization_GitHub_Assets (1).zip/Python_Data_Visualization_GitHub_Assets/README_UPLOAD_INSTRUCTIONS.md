# GitHub Assets — Python Data Visualization Assignment

This package contains the screenshots supplied for the assignment, organized for the repository.

## Upload structure

- `outputs/` — supplied Jupyter screenshots, with descriptive filenames.
- `docs/` — original assignment PDF and the supplied notebook/HTML exports for reference.

## Suggested GitHub destination

Copy the contents into the existing repository:

`shanmukhkoyya/Python-Data-Visualization-Assignment`

Keep the screenshots in `outputs/` and reference them from the repository README if desired.

## Screenshot authenticity

These are the user's supplied screenshots. They have been copied without recreating the charts.
